友盟组件主题
=======================

此工程提供针对友盟 组件 的多种主题样式。

1. [双向反馈](https://github.com/ntop001/umeng-android-sdk-theme/tree/master/fb)
2. [自动更新](https://github.com/ntop001/umeng-android-sdk-theme/tree/master/update)
