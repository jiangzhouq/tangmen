pybcs.rst
#################################

.. contents:: Table of Contents

windows (设置环境变量) ::
    set SK=xxx
    set SK=xxxxx

