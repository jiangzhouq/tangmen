#!/usr/bin/env python
#coding:utf8

import os
import logging
import pybcs 

#设置日志级别
pybcs.init_logging(logging.INFO)


# 请修改这里
AK = os.environ['AK']           #请改为你的AK
SK = os.environ['SK']         #请改为你的SK
BUCKET='bcs-test'



bcs = pybcs.BCS('http://bcs.duapp.com/', AK, SK, pybcs.HttplibHTTPC)    #这里可以显式选择使用的HttpClient, 可以是:
                                                                        #HttplibHTTPC
                                                                        #PyCurlHTTPC
lst = bcs.list_buckets()
print '---------------- list of bucket : '
for b in lst:
    print b
print '---------------- list end'

#声明一个bucket
b = bcs.bucket(BUCKET)

#创建bucket (创建后需要在yun.baidu.com 手动调整quota, 否则无法上传下载)
#b.create()

#获取bucket acl, 内容是json
print b.get_acl()['body']

#将bucket 设置为公有可读写
#b.make_public()

#声明一个object
o = b.object('/test.png')
o.put_file('test/data/中文.data')
o.get_to_file('test/data/xxx.download.data')

#在bcs 上删除.
#o.delete()
